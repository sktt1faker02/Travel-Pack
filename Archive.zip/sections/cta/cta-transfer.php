    <div class="mt-4 tp-main-cta tp-main-cta-transfer">
        <div class="tp-main-cta-wrap" style="background-image:url(<?= getBaseUrl() ?>/assets/img/cta/cta-transfer.jpg)">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="ctawhitebox">
                        <h2 class="largesectiontitle">
                            Need a transfer?
                        </h2>
                        <p>
                            Book a seamless transfer now so you can rest once you have arrived
                        </p>

                        <a href="<?= getBaseUrl() ?>/transfer" class="btn btn-primary">View Transfers</a>
                    </div><!-- cta whitebox -->
                </div><!-- col -->
            </div><!-- row -->
        </div><!-- tp main cta wrap -->
    </div>