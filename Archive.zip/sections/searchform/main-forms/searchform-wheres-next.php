<div class="searchbar-main" id="searchbar-car-hire">
    <div class="searchbar-main-inner">
        <form name="car-hire-search" id="car-hire-search" method="post" action="">
        <div class="searchform-inner">
                    <div class="searchform-row">
                        <div class="searchbar-inputwrap flex100-mobile mobile-last-col">
                            <input type="text" class="form-control" autocomplete="viator" name="exc-text" id="exc-text" value="" placeholder="Where">
                        </div>
                        <div class="searchbar-inputwrap flex100-mobile mobile-bordertop mobile-last-col">
                            <input class="form-control date initialize-date-picker hasDatepicker" name="exc-date" id="cruises-departure" value="" placeholder="When">
                        </div>

                        <div class="searchnow-btn flex5 searchbar-inputwrap mobile-bordertop flex100-mobile">
                            <a class="btn-typ2 searchnowbtn btn btn-primary" href="javascript:void(0);" title="Search Now">Search Now</a>
                        </div>
                    </div><!-- searchform-row -->
                </div>
        </form><!-- form -->
    </div>
</div><!-- searchbar main -->