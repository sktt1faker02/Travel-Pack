
<section class="block bggray rightsideslider" id="perfect-holiday">
        <div class="container">
            <div class="row mb-4 align-items-center">
                <div class="col-8 col-lg-6">
                    <h2 class="homesectiontitle">
                        Your Perfect Holiday
                    </h2>
                </div><!-- col -->
                <div class="col-4 col-lg-6 d-flex justify-content-end">
                    <a href="#" class="fw-semibold view-all">View All <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div><!-- row -->
        </div><!-- container -->
		    
        <div class="rowslider tpslider-2  perfectholidayslider firstload">
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph1.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Kids Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph2.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Couple Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph3.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Couple Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph1.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Couple Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph2.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Couple Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            <div class="yphbox innerrowslider">
                <div class="yellowtagwrap">
                    <div class="yph-price global-price-tag">
                        <a href="#">
                            Save <strong>15%</strong> On Hotel Bookings 
                        </a>
                    </div>
                </div>
                <img src="<?= getBaseUrl() ?>/assets/img/home/yph3.jpg" alt="">
                <div class="yph-details">
                    <div class="yph-title">
                        <h3>
                            Couple Holidays
                        </h3>
                    </div>

                    <a href="#" class="fw-semibold yph-more">Find Out More <i class="fa-solid fa-chevron-right"></i></a>
                </div>
            </div>
            
            
        </div>
    </section>    