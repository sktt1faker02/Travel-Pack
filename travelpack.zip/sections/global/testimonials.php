
    <section class="block bggray" id="testimonials">
        <div class="container">
            <div class="row">
                <div class="col-12 mb-3 mb-md-4 pb-2">
                    <h2 class="homesectiontitle text-center text-lg-start">Don't Just listen to us</h2>
                </div>
            </div>
        </div>
        <div id="main-testimonials">
            <div class="testislider">
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            Quick and Simple
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            Fast processing
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            Hassle free!
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            Easy and Fast
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <div class="esd-rating">
                        5 <i class="fa-solid fa-star"></i>
                    </div>
                    <div class="testimain">
                        <h3>
                            Awesome and great!
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            So far so good
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
                <div class="testibox">
                    <?php include './sections/global/star-rating.php';?>
                    <div class="testimain">
                        <h3>
                            Efficient and Fast
                        </h3>
                        <p>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
                        </p>
                    </div>
                    <div class="testi-author">
                        Zara
                    </div>
                </div>
            </div><!-- testislider -->
        </div>

    </section>