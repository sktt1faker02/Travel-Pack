
    <div class="esd-rating">
        4.5 <div><img src="<?= getBaseUrl() ?>/assets/img/icons/icon-star.png" class="icon-star" alt="star"></div> 
    </div>