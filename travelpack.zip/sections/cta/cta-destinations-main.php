    <div class="mt-4 tp-main-cta tp-main-cta-hotels">
        <div class="tp-main-cta-wrap" style="background-image:url(<?= getBaseUrl() ?>/assets/img/cta/cta-destinations-main.jpg)">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="ctawhitebox">
                        <h2 class="largesectiontitle">
                            Need flights to London?
                        </h2>
                        <p>
                            Select from oue wide range of offers for flights
                        </p>

                        <a href="<?= getBaseUrl() ?>/flights" class="btn btn-primary">Book Flights</a>
                    </div><!-- cta whitebox -->
                </div><!-- col -->
            </div><!-- row -->
        </div><!-- tp main cta wrap -->
    </div><!-- tpmiancta -->