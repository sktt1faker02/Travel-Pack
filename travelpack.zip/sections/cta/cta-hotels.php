    <div class="mt-4 tp-main-cta tp-main-cta-hotels">
        <div class="tp-main-cta-wrap" style="background-image:url(<?= getBaseUrl() ?>/assets/img/cta/cta-hotels.jpg)">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="ctawhitebox">
                        <h2 class="largesectiontitle">
                            Where are you going to stay?
                        </h2>
                        <p>
                            Book a hotel through our endless options of hotels with exciting deals
                        </p>

                        <a href="<?= getBaseUrl() ?>/hotels" class="btn btn-primary">View Hotels</a>
                    </div><!-- cta whitebox -->
                </div><!-- col -->
            </div><!-- row -->
        </div><!-- tp main cta wrap -->
    </div>