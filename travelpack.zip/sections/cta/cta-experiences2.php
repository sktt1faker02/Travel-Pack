    <div class="mt-4 tp-main-cta tp-main-cta-hotels">
        <div class="tp-main-cta-wrap" style="background-image:url(<?= getBaseUrl() ?>/assets/img/cta/cta-experiences2.jpg)">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <div class="ctawhitebox">
                        <h2 class="largesectiontitle">
                            Want to experience the local magic?
                        </h2>
                        <p>
                            Book an experience through our endless options of experiences.
                        </p>

                        <a href="<?= getBaseUrl() ?>/experiences" class="btn btn-primary">View Experiences</a>
                    </div><!-- cta whitebox -->
                </div><!-- col -->
            </div><!-- row -->
        </div><!-- tp main cta wrap -->
    </div>